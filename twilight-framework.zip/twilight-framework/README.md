# Twilight Framework

Twilight Framework is a modern role‑play framework built for **FiveM** servers.  It draws inspiration from existing RP frameworks but aims to provide a more modular, optimized, and well‑documented foundation for custom servers.  This repository contains the initial scaffolding for the framework based on the provided master plan.

## Features (Planned)

* **Core Resource** – Handles player lifecycle, database interactions, and provides exports to other scripts.
* **Strictly Server‑authoritative Economy and Jobs** – Secure transaction handling and job management.
* **Inventory System** – A server‑side, authoritative inventory with metadata and configurable limits.
* **Modular Components** – Each subsystem (economy, jobs, inventory) lives in its own resource so server owners can mix and match or extend them.
* **NUI Friendly** – The client side is prepared for modern front‑end frameworks such as React or Svelte for high performance user interfaces.
* **Logging and Administration Tools** – Hooks for webhook logging and an in‑game administration menu are stubbed for later implementation.

## Structure

The framework uses the standard **FiveM resource** layout.  All resources live under the `resources` directory.  Currently only the `twilight‑core` resource is provided as a starting point.

```
twilight-framework/
├── resources
│   └── twilight-core
│       ├── fxmanifest.lua
│       ├── client
│       │   └── main.lua
│       ├── server
│       │   ├── main.lua
│       │   └── player_class.lua
│       └── shared
│           ├── config.lua
│           └── util.lua
└── sql
    └── schema.sql
```

### sql/schema.sql

Contains SQL statements to create the necessary tables (`players`, `characters` and `player_data`) in your MariaDB/MySQL database.  Adjust column types and lengths as needed.

### resources/twilight-core

This resource holds the core of the framework.  It defines the **Player** class on the server, manages player connections/disconnections, and exposes exports for other scripts.  The client side currently only contains a minimal placeholder, ready for integration with your NUI (React/Svelte) UI.

### shared/config.lua

Holds configuration options such as database table names, initial balances, and other tunables.  Server owners should modify these values to suit their server’s needs.

## Getting Started

1. Install and configure **MariaDB** or **MySQL** on your server.
2. Create a database for your server and execute the SQL file in [`sql/schema.sql`](sql/schema.sql) to create the required tables.
3. Copy the `twilight-core` folder into your server’s `resources` directory and ensure `oxmysql` is installed and configured.
4. Add `ensure twilight-core` to your `server.cfg`.
5. Start your server and check the logs.  The framework should print “Twilight Core loaded” if initialization succeeds.

## Contributing

This project is in its infancy.  Contributions are welcome, whether through pull requests, feature suggestions, or bug reports.  Please follow the coding style present in the existing files and include documentation for any exports or events that you add.

## License

This project is released under the MIT License.  See the `LICENSE` file for more details.