-- Twilight Framework database schema

-- Table: players
-- Holds unique player identifiers and basic metadata not tied to a specific character.
CREATE TABLE IF NOT EXISTS `players` (
    `license`   VARCHAR(50) NOT NULL,
    `steam`     VARCHAR(50) DEFAULT NULL,
    `discord`   VARCHAR(50) DEFAULT NULL,
    `playtime`  INT UNSIGNED NOT NULL DEFAULT 0,
    `bans`      INT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (`license`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: characters
-- Each player can have multiple characters.  Contains identity and financial information.
CREATE TABLE IF NOT EXISTS `characters` (
    `cid`       INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `license`   VARCHAR(50) NOT NULL,
    `citizenid` VARCHAR(50) NOT NULL,
    `firstname` VARCHAR(50) NOT NULL,
    `lastname`  VARCHAR(50) NOT NULL,
    `dob`       DATE NOT NULL,
    `gender`    TINYINT NOT NULL,
    `cash`      INT NOT NULL DEFAULT 0,
    `bank`      INT NOT NULL DEFAULT 0,
    `job`       JSON DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`cid`),
    KEY `idx_license` (`license`),
    CONSTRAINT `fk_characters_players` FOREIGN KEY (`license`) REFERENCES `players` (`license`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: player_data
-- Stores persistent state for each character (inventory, job, metadata, last position, etc.).
CREATE TABLE IF NOT EXISTS `player_data` (
    `cid`       INT UNSIGNED NOT NULL,
    `inventory` JSON DEFAULT NULL,
    `job`       JSON DEFAULT NULL,
    `metadata`  JSON DEFAULT NULL,
    `position`  VARCHAR(100) DEFAULT NULL,
    PRIMARY KEY (`cid`),
    CONSTRAINT `fk_player_data_characters` FOREIGN KEY (`cid`) REFERENCES `characters` (`cid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;