--[[
    Twilight Core - Client Entry Point

    This script runs on the client and handles user interface interactions.
    Currently it listens for the `twilight:playerLoaded` event triggered
    by the server when a player’s character finishes loading, and prints
    a welcome message.  Future work will integrate with a NUI built in
    React, Svelte or Vue.js.
--]]

local function onPlayerLoaded(charData)
    -- charData contains the loaded character information from the server
    local fname = charData.firstname or 'Unknown'
    local lname = charData.lastname or ''
    local message = ('Welcome back, %s %s!'):format(fname, lname)
    -- Use the GTA notification style as a placeholder until NUI is integrated
    SetNotificationTextEntry('STRING')
    AddTextComponentString(message)
    DrawNotification(false, false)
end

RegisterNetEvent('twilight:playerLoaded', onPlayerLoaded)

-- Development test command to print player coordinates
RegisterCommand('coords', function()
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local msg = ('Your position: x=%.2f y=%.2f z=%.2f'):format(pos.x, pos.y, pos.z)
    TriggerEvent('chat:addMessage', { args = { '^7[Coords]', msg } })
end, false)