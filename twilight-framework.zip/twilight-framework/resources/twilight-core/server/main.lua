--[[
    Twilight Core - Server Entry Point

    This script manages the player connection pipeline and exposes
    exports/events for other resources to interact with the framework.
--]]

local Config = require 'shared/config'
local util   = require 'shared/util'
local Player = require 'server/player_class'

-- Helper to convert FiveM identifiers into a table
local function GetIdentifiers(src)
    local identifiers = {
        license = nil,
        steam   = nil,
        discord = nil
    }
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:sub(1, 8) == 'license:' then
            identifiers.license = id:sub(9)
        elseif id:sub(1, 6) == 'steam:' then
            identifiers.steam = id:sub(7)
        elseif id:sub(1, 9) == 'discord:' then
            identifiers.discord = id:sub(10)
        end
    end
    return identifiers
end

-- Player connecting pipeline
AddEventHandler('playerConnecting', function(playerName, setKickReason, deferrals)
    local src = source
    deferrals.defer()
    deferrals.update(('Hello %s, checking your data...'):format(playerName))
    local identifiers = GetIdentifiers(src)
    if not identifiers.license then
        deferrals.done('No valid rockstar license found.')
        return
    end
    -- TODO: whitelist/ban checks can be inserted here
    Player.load(src, identifiers, function(player)
        Twilight.Players[src] = player
        util.debug(('Loaded player %s (%s)'):format(src, identifiers.license))
        deferrals.update('Data loaded. Welcome to the server!')
        deferrals.done()
    end)
end)

-- Player joined event
AddEventHandler('playerJoining', function(oldId)
    local src = source
    local player = Twilight.Players[src]
    if not player then
        util.debug(('playerJoining fired but player %s not yet loaded'):format(src))
        return
    end
    -- Trigger event for other resources to handle spawn logic
    -- This event is server‑side only for scripts to hook into.
    TriggerEvent('twilight:playerLoaded', src, player)

    -- Also notify the client that their character has loaded
    TriggerClientEvent('twilight:playerLoaded', src, player.charData)
end)

-- Player dropped event
AddEventHandler('playerDropped', function(reason)
    local src = source
    local player = Twilight.Players[src]
    if player then
        util.debug(('Player %s dropped (%s), saving...'):format(src, reason))
        player:Save()
        Twilight.Players[src] = nil
    end
end)

-- Export: Get player object by ID
exports('GetPlayer', function(src)
    return Twilight.Players[src]
end)

-- Export: Check if a player has a permission level or higher
exports('HasPermission', function(src, level)
    local player = Twilight.Players[src]
    if not player then return false end
    local rank = player.charData.metadata.rank or Config.Permissions.user
    return rank >= level
end)

print('^2[Twilight Core]^0 Loaded core framework')