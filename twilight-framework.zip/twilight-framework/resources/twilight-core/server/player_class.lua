--[[
    Twilight Player Class

    Defines the Player object for the Twilight framework.  Instances of this
    class represent connected players and their associated characters.  All
    gameplay logic that modifies a player’s state (money, job, inventory)
    should go through methods defined here to ensure server‑side
    authority and consistent database persistence.
--]]

local Config = require 'shared/config'
local util   = require 'shared/util'

Twilight = Twilight or {}
Twilight.Players = Twilight.Players or {}

local Player = {}
Player.__index = Player

---Create a new Player instance.
---@param source number The server ID of the player
---@param identifiers table A table of identifiers (license, steam, discord)
---@param charData table|nil Previously loaded character data, or nil for new players
function Player.new(source, identifiers, charData)
    local self = setmetatable({}, Player)

    self.source       = source
    self.identifiers  = identifiers or {}
    self.license      = identifiers.license
    self.steamId      = identifiers.steam
    self.discord      = identifiers.discord

    -- Character data will hold persistent stats such as money, job, and metadata.
    -- This is loaded from the database on playerJoin.  If no data exists
    -- the defaults from Config will be used instead.
    self.charData     = charData or {
        cid       = nil,
        citizenid = nil,
        firstname = 'John',
        lastname  = 'Doe',
        dob       = '1900-01-01',
        gender    = 0,
        accounts  = {
            cash = Config.StartingCash,
            bank = Config.StartingBank,
        },
        job      = Config.DefaultJob,
        inventory = {},
        metadata = {},
        position = vector3(0, 0, 0)
    }

    return self
end

--[[ Money API ]]

---Add money to an account.
---@param account string The account type ('cash' or 'bank')
---@param amount number The amount to add
function Player:AddMoney(account, amount)
    amount = tonumber(amount) or 0
    if amount <= 0 then return end

    if not Config.Accounts[account] then
        util.debug(('Unknown account type %s'):format(account))
        return
    end

    self.charData.accounts[account] = (self.charData.accounts[account] or 0) + amount
    util.debug(('Added $%s %s to player %s'):format(amount, account, self.source))
    self:Save()
end

---Remove money from an account.
---@param account string The account type
---@param amount number The amount to remove
function Player:RemoveMoney(account, amount)
    amount = tonumber(amount) or 0
    if amount <= 0 then return end
    if not Config.Accounts[account] then
        util.debug(('Unknown account type %s'):format(account))
        return
    end
    local current = self.charData.accounts[account] or 0
    if current < amount then
        amount = current
    end
    self.charData.accounts[account] = current - amount
    util.debug(('Removed $%s %s from player %s'):format(amount, account, self.source))
    self:Save()
end

---Get the balance of an account.
---@param account string
---@return number
function Player:GetMoney(account)
    return self.charData.accounts[account] or 0
end

--[[ Job API ]]

---Set the player's job and grade.
---@param jobName string
---@param grade number
function Player:SetJob(jobName, grade)
    self.charData.job = {
        name  = jobName,
        grade = grade or 0
    }
    util.debug(('Set job for player %s to %s (%s)'):format(self.source, jobName, grade))
    self:Save()
end

---Get the player's job table.
---@return table
function Player:GetJob()
    return self.charData.job
end

--[[ Inventory API ]]

---Get the player's inventory table.
---@return table
function Player:GetInventory()
    return self.charData.inventory
end

---Add an item to the player's inventory.
---@param itemName string
---@param amount number
---@param metadata table|nil
function Player:AddItem(itemName, amount, metadata)
    amount  = amount or 1
    metadata = metadata or {}
    local inv = self.charData.inventory
    inv[itemName] = inv[itemName] or { count = 0, metadata = {} }
    inv[itemName].count    = inv[itemName].count + amount
    -- We ignore metadata merging in this stub; in a complete implementation
    -- you would handle stacking vs. new entries here.
    util.debug(('Gave %s x%d to player %s'):format(itemName, amount, self.source))
    self:Save()
end

---Remove an item from the player's inventory.
---@param itemName string
---@param amount number
function Player:RemoveItem(itemName, amount)
    amount = amount or 1
    local inv = self.charData.inventory
    if not inv[itemName] then return end
    if inv[itemName].count < amount then
        amount = inv[itemName].count
    end
    inv[itemName].count = inv[itemName].count - amount
    if inv[itemName].count <= 0 then
        inv[itemName] = nil
    end
    util.debug(('Removed %s x%d from player %s'):format(itemName, amount, self.source))
    self:Save()
end

--[[ Persistence API ]]

---Save the player's current state to the database.
---This function uses oxmysql to perform an upsert into the player_data table.
function Player:Save()
    -- Flatten inventory and metadata into JSON strings for storage
    local inventoryJson = json.encode(self.charData.inventory)
    local metaJson      = json.encode(self.charData.metadata)
    local position      = self.charData.position
    local posString     = ('%s,%s,%s'):format(position.x, position.y, position.z)

    MySQL.Async.execute((
        'INSERT INTO `%s` (cid, inventory, job, metadata, position) '
      .. 'VALUES (@cid, @inventory, @job, @metadata, @position) '
      .. 'ON DUPLICATE KEY UPDATE inventory=@inventory, job=@job, metadata=@metadata, position=@position'
    ):format(Config.Database.player_data), {
        ['@cid']       = self.charData.cid,
        ['@inventory'] = inventoryJson,
        ['@job']       = json.encode(self.charData.job),
        ['@metadata']  = metaJson,
        ['@position']  = posString
    }, function(affectedRows)
        util.debug(('Saved player %s to database (%d rows)'):format(self.source, affectedRows or 0))
    end)
end

---Kick the player with a custom message.
---@param reason string
function Player:Kick(reason)
    reason = reason or 'You have been kicked from the server.'
    DropPlayer(self.source, reason)
end

--[[ Static Methods ]]

---Load a player by identifiers from the database, returning a Player instance.
---This function is asynchronous; it invokes the callback with the created Player.
---@param source number
---@param identifiers table
---@param callback fun(player: Player)
function Player.load(source, identifiers, callback)
    local license = identifiers.license
    local charData = nil
    -- Attempt to load the most recent character for this license
    MySQL.Async.fetchAll((
        'SELECT c.*, p.accounts FROM `%s` c
         JOIN `%s` p ON c.cid = p.cid
         WHERE p.license = @license LIMIT 1'
    ):format(Config.Database.characters, Config.Database.players), {
        ['@license'] = license
    }, function(results)
        if results and #results > 0 then
            local row = results[1]
            -- Parse accounts JSON; fallback if missing
            local accounts = {
                cash = tonumber(row.cash) or Config.StartingCash,
                bank = tonumber(row.bank) or Config.StartingBank
            }
            charData = {
                cid       = row.cid,
                citizenid = row.citizenid,
                firstname = row.firstname,
                lastname  = row.lastname,
                dob       = row.dob,
                gender    = row.gender,
                accounts  = accounts,
                job       = json.decode(row.job or '{}') or Config.DefaultJob,
                inventory = json.decode(row.inventory or '{}') or {},
                metadata  = json.decode(row.metadata or '{}') or {},
                position  = parsePosition(row.position)
            }
        end
        local player = Player.new(source, identifiers, charData)
        callback(player)
    end)
end

---Parse a stored position string into a vector3.
---@param posStr string
---@return vector3
function parsePosition(posStr)
    if type(posStr) == 'string' then
        local x, y, z = posStr:match('([^,]+),([^,]+),([^,]+)')
        if x and y and z then
            return vector3(tonumber(x), tonumber(y), tonumber(z))
        end
    end
    return vector3(0, 0, 0)
end

-- Expose the Player class globally via Twilight.Player
Twilight.Player = Player

return Player