--[[
    Shared Utility Functions

    Utility functions that can be used by both client and server scripts
    within the Twilight framework.  Keep pure Lua helpers here rather
    than mixing them into resource logic.
--]]

local util = {}

-- Toggle to enable/disable verbose debugging messages.  This can be
-- overridden at runtime by setting the convar `twilight_debug` to 1.
util.debugEnabled = GetConvar('twilight_debug', '0') == '1'

---Print a formatted debug message if debugging is enabled.
---@param ... any The values to print
function util.debug(...)
    if util.debugEnabled then
        local args = { ... }
        local prefix = '^6[TWILIGHT DEBUG]^0'
        local message = table.concat(args, ' ')
        print(prefix .. ' ' .. message)
    end
end

return util