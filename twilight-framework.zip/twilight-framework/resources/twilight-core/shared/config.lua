--[[
    Twilight Framework Configuration

    This file contains configuration variables that control the behaviour of
    the core framework.  Server owners should adjust these values to suit
    their server’s needs.  Whenever possible, avoid editing code directly
    in the core – instead expose settings here for maintainability.
--]]

local Config = {}

-- Database table names.  Modify if you change schema names in `sql/schema.sql`.
Config.Database = {
    players     = 'players',      -- Basic player identifiers and metadata
    characters  = 'characters',   -- Character identity and finances
    player_data = 'player_data'   -- Player state (inventory, job, location, etc.)
}

-- Initial account balances for new characters (in dollars).
Config.StartingCash  = 500
Config.StartingBank  = 5000

-- List of account types used by the framework
Config.Accounts = {
    cash  = true,
    bank  = true,
    crypto = false -- set to true when crypto support is implemented
}

-- Default job assigned to new characters (change in job system later)
Config.DefaultJob = {
    name  = 'unemployed',
    grade = 0
}

-- Logging settings (Discord webhook URLs).  Leave empty to disable.
Config.Webhooks = {
    transactions = '',
    admin_actions = ''
}

-- Administrative permission levels
-- The numeric value corresponds to the highest granted privilege (higher
-- numbers mean more privileges).  These can be compared to the `Player.rank` in the future.
Config.Permissions = {
    user    = 0,
    moderator = 1,
    admin   = 2,
    superadmin = 3
}

return Config