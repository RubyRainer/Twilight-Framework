fx_version 'cerulean'
game 'gta5'

author 'Twilight Team'
description 'Core resource for Twilight Framework'
version '0.1.0'

-- Dependency: ensure oxmysql is installed and configured in your server.cfg
dependency 'oxmysql'

-- Shared scripts are loaded by both client and server
shared_scripts {
    'shared/config.lua',
    'shared/util.lua'
}

-- Server scripts
server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/player_class.lua',
    'server/main.lua'
}

-- Client scripts
client_scripts {
    'client/main.lua'
}

-- Lua 5.4 runtime support can be enabled if desired
lua54 'yes'